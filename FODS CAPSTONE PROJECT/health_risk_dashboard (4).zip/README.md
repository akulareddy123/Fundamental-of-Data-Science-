# Early Health Risk — Statistical Analysis Dashboard

Implementation for: **Exploratory Statistical Analysis of Clinical and
Lifestyle Indicators for Early Health Risk** (DSA04 — Fundamentals of Data
Science)

Pipeline: **upload/clean → exploratory data analysis → statistical
correlation → statistical risk scoring**. No ML/DL model is trained
anywhere — every number the dashboard shows (correlations, t-tests,
z-scores, percentiles) is a directly computable statistic.

**The backend is dataset-agnostic.** It doesn't just work on Framingham —
upload any health CSV with a two-class outcome column and it will:
- auto-detect (or let you manually pick) which column is the outcome
- classify every other column as numeric, binary, or excluded
  (identifier columns, constant columns, and >2-level categoricals are
  excluded from the statistical pipeline and listed transparently)
- binarize non-numeric two-class columns (e.g. `M`/`B`, `Yes`/`No`)
  automatically
- rebuild the entire EDA/correlation/risk-score pipeline around whatever
  columns survive

---

## 1. Datasets

**Bundled by default:** `backend/data/framingham.csv` — a synthetically
generated dataset matching the real Kaggle Framingham Heart Study
dataset's exact schema, value ranges, and missingness pattern (this
sandbox has no internet access to kaggle.com, so the real file couldn't
be downloaded directly here).

**Real datasets verified to work with this app** (download the CSV from
Kaggle, then use the **Upload CSV** button — no code changes needed):

| Dataset | Kaggle link | Outcome column | Notes |
|---|---|---|---|
| Framingham Heart Study | [aasheesh200/framingham-heart-study-dataset](https://www.kaggle.com/datasets/aasheesh200/framingham-heart-study-dataset) | `TenYearCHD` | matches the bundled dataset exactly |
| Pima Indians Diabetes | [uciml/pima-indians-diabetes-database](https://www.kaggle.com/datasets/uciml/pima-indians-diabetes-database) | `Outcome` | auto-detects target via name match. **Known quirk:** `Glucose`, `BloodPressure`, `SkinThickness`, `Insulin`, `BMI` use literal `0` to mean "missing" — these are valid-looking numbers, not blanks, so the cleaning step won't catch them automatically. Worth mentioning if asked. |
| Breast Cancer Wisconsin (Diagnostic) | [uciml/breast-cancer-wisconsin-data](https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data) | `diagnosis` (`M`/`B`) | `id` column auto-excluded as an identifier; string target auto-binarized. Some re-uploads include a trailing all-blank `Unnamed: 32` column — auto-excluded as constant/all-missing. |
| Stroke Prediction | [fedesoriano/stroke-prediction-dataset](https://www.kaggle.com/datasets/fedesoriano/stroke-prediction-dataset) | `stroke` | `id` auto-excluded. `gender` may have 3 levels (Male/Female/Other) — if so it's excluded as a >2-level categorical, which is expected, not a bug. |
| Heart Disease (UCI/Cleveland) | [johnsmith88/heart-disease-dataset](https://www.kaggle.com/datasets/johnsmith88/heart-disease-dataset) | `target` | column literally named `target`, auto-detects immediately. |

If a dataset's outcome column can't be auto-detected, the dashboard shows
a picker modal so you can choose it manually — no need to touch the code
or restart the server.

---

## 2. Setup

```bash
cd backend
pip install -r requirements.txt
```

## 3. Run

```bash
cd backend
uvicorn main:app --reload --port 8000
```

Open **http://localhost:8000** — the dashboard is served directly by the
backend, so there's nothing separate to start for the frontend.

---

## 4. What the dashboard shows

1. **Dataset Overview** — row/column counts, missing-cell count, outcome
   class balance, which column is being used as the outcome, and which
   columns (if any) were excluded and why
2. **Data Cleaning Report** — exactly which columns had missing values,
   how many, and the imputation method used (median for numeric, mode
   for binary) — nothing is silently dropped
3. **Exploratory Data Analysis** — per-feature distribution histograms,
   an outcome-group comparison with an independent t-test, and a full
   descriptive statistics table (mean/median/std/min/max)
4. **Statistical Correlation** — Pearson correlation of every numeric/
   binary indicator against the outcome, with p-values; bars are
   colour-coded by statistical significance (p < 0.05)
5. **Statistical Risk Score Calculator** — form fields are generated
   dynamically from whichever features turned out to be statistically
   significant for the currently loaded dataset. Enter an individual's
   values and get a **correlation-weighted z-score**, ranked as a
   **percentile against the study population** — an explicit statistical
   comparison, not a trained prediction. The breakdown table shows the
   exact contribution of each factor.

## 5. Project structure

```
backend/
  main.py              FastAPI app — schema auto-detection + statistical engine
  requirements.txt
  data/
    framingham.csv          bundled dataset (swap with any real Kaggle file)
    generate_dataset.py      script that built the bundled dataset
frontend/
  index.html           dashboard layout (incl. target-picker modal)
  style.css            styling
  app.js               fetches from the API, builds dynamic charts/forms
  chart.umd.min.js     Chart.js, bundled locally (no CDN dependency)
```

## 6. API reference

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/overview` | dataset size, missing cells, outcome distribution, excluded columns |
| GET | `/api/clean-report` | per-column missing counts + imputation method used |
| GET | `/api/eda/summary` | descriptive statistics per numeric feature |
| GET | `/api/eda/histogram?column=age` | histogram bins/counts for one feature |
| GET | `/api/eda/correlation` | Pearson correlation + p-value of every feature vs. outcome |
| GET | `/api/eda/grouped-comparison?column=sysBP` | group means + t-test between outcome classes |
| GET | `/api/risk-score/reference` | which fields the risk-score form should render, and their weights |
| POST | `/api/risk-score` | compute one individual's statistical risk percentile |
| POST | `/api/upload` | replace the active dataset with an uploaded CSV; auto-detects the outcome column |
| POST | `/api/set-target` | manually set which column is the outcome (used when auto-detection can't decide, or to override it) |
| POST | `/api/reset` | revert to the bundled Framingham dataset |
