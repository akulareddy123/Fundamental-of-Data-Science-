const API = "";
const COLORS = { blue: "#2E5C8A", lblue: "#EAF2FB", orange: "#B57A2E", teal: "#2E8E86", green: "#3E8E5A", gray: "#98A2B3" };

// Optional friendlier labels for well-known column names; anything not
// listed here just falls back to the raw column name so this still works
// on datasets we've never seen.
const FEATURE_LABELS = {
  age: "Age", education: "Education Level", cigsPerDay: "Cigarettes / Day",
  totChol: "Total Cholesterol", sysBP: "Systolic BP", diaBP: "Diastolic BP",
  BMI: "BMI", heartRate: "Heart Rate", glucose: "Glucose",
  male: "Male", currentSmoker: "Current Smoker", BPMeds: "On BP Medication",
  prevalentStroke: "History of Stroke", prevalentHyp: "Hypertensive",
  diabetes: "Diabetes", Outcome: "Outcome", Pregnancies: "Pregnancies",
  BloodPressure: "Blood Pressure", SkinThickness: "Skin Thickness",
  Insulin: "Insulin", DiabetesPedigreeFunction: "Diabetes Pedigree", Age: "Age",
};

function label(name) {
  return FEATURE_LABELS[name] || name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
}

// For columns already coded as plain 0/1 with no descriptive original values,
// swap in friendlier Yes/No (or Male/Female) wording where we recognize the
// column name. Unknown columns just keep whatever the backend reports.
const BINARY_LABEL_OVERRIDES = {
  male: { 0: "Female", 1: "Male" },
  currentSmoker: { 0: "No", 1: "Yes" },
  diabetes: { 0: "No", 1: "Yes" },
  prevalentHyp: { 0: "No", 1: "Yes" },
  prevalentStroke: { 0: "No", 1: "Yes" },
  BPMeds: { 0: "No", 1: "Yes" },
  hypertension: { 0: "No", 1: "Yes" },
  heart_disease: { 0: "No", 1: "Yes" },
};

function binaryLabels(feature, label0, label1) {
  if ((label0 === "0" && label1 === "1") && BINARY_LABEL_OVERRIDES[feature]) {
    const o = BINARY_LABEL_OVERRIDES[feature];
    return [o[0], o[1]];
  }
  return [label0, label1];
}

let charts = {};
function destroyChart(key) {
  if (charts[key]) { charts[key].destroy(); charts[key] = null; }
}

async function api(path, opts) {
  const res = await fetch(API + path, opts);
  if (!res.ok) {
    const err = await res.json().catch(() => ({ detail: res.statusText }));
    throw new Error(err.detail || "Request failed");
  }
  return res.json();
}

// ---------------------------------------------------------------- overview
async function loadOverview() {
  const data = await api("/api/overview");
  const dist = data.target_distribution;
  const labels = data.target_labels || {};
  const totalMissing = data.total_missing_cells;
  const key1 = "1", count1 = dist[key1] ?? 0;
  const cards = [
    { label: "Rows", value: data.rows.toLocaleString(), cls: "" },
    { label: "Columns", value: data.columns, cls: "" },
    { label: "Missing Cells", value: totalMissing.toLocaleString(), cls: "orange" },
    { label: `Outcome = ${labels["1"] ?? "1"}`, value: `${count1} (${(100 * count1 / data.rows).toFixed(1)}%)`, cls: "teal" },
  ];
  document.getElementById("overviewCards").innerHTML = cards.map(c => `
    <div class="stat-card ${c.cls}">
      <div class="label">${c.label}</div>
      <div class="value">${c.value}</div>
    </div>`).join("");

  document.getElementById("targetBar").innerHTML =
    `Outcome column in use: <b>${data.target}</b> (${labels["0"] ?? "0"} = 0, ${labels["1"] ?? "1"} = 1) &nbsp;·&nbsp; ` +
    `${data.numeric_features.length} numeric + ${data.binary_features.length} binary feature(s) used`;

  const excludedEl = document.getElementById("excludedNote");
  if (data.excluded_columns && data.excluded_columns.length) {
    excludedEl.classList.remove("hidden");
    excludedEl.textContent = "Excluded from analysis: " +
      data.excluded_columns.map(e => `${e.column} (${e.reason})`).join("; ");
  } else {
    excludedEl.classList.add("hidden");
    excludedEl.textContent = "";
  }
}

// ------------------------------------------------------------ clean report
async function loadCleanReport() {
  const data = await api("/api/clean-report");
  const tbody = document.querySelector("#cleanTable tbody");
  tbody.innerHTML = data.report.map(r => `
    <tr>
      <td>${label(r.feature)}</td>
      <td>${r.missing_count}</td>
      <td>${r.missing_pct}%</td>
      <td>${r.method}</td>
    </tr>`).join("") || `<tr><td colspan="4">No missing values found.</td></tr>`;
}

// -------------------------------------------------------------------- EDA
async function loadEdaSummary() {
  const data = await api("/api/eda/summary");
  const tbody = document.querySelector("#summaryTable tbody");
  tbody.innerHTML = data.summary.map(r => `
    <tr>
      <td>${label(r.feature)}</td>
      <td>${r.mean}</td><td>${r.median}</td><td>${r.std}</td><td>${r.min}</td><td>${r.max}</td>
    </tr>`).join("");

  const select = document.getElementById("histFeature");
  select.innerHTML = data.summary.map(r => `<option value="${r.feature}">${label(r.feature)}</option>`).join("");
  const groupSelect = document.getElementById("groupFeature");
  groupSelect.innerHTML = select.innerHTML;
  return data.summary.length > 0;
}

async function loadHistogram(column) {
  if (!column) return;
  const data = await api(`/api/eda/histogram?column=${encodeURIComponent(column)}&bins=12`);
  destroyChart("hist");
  const ctx = document.getElementById("histChart");
  charts.hist = new Chart(ctx, {
    type: "bar",
    data: { labels: data.labels, datasets: [{ label: "Count", data: data.counts, backgroundColor: COLORS.blue, borderRadius: 4 }] },
    options: {
      plugins: { legend: { display: false } },
      scales: { x: { ticks: { font: { size: 10 } } }, y: { beginAtZero: true } },
    },
  });
}

async function loadGroupComparison(column) {
  if (!column) return;
  const data = await api(`/api/eda/grouped-comparison?column=${encodeURIComponent(column)}`);
  destroyChart("group");
  const ctx = document.getElementById("groupChart");
  charts.group = new Chart(ctx, {
    type: "bar",
    data: {
      labels: [`Outcome = ${data.group_0_label}`, `Outcome = ${data.group_1_label}`],
      datasets: [{ data: [data.mean_group_0, data.mean_group_1], backgroundColor: [COLORS.teal, COLORS.orange], borderRadius: 6 }],
    },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } },
  });
  const sigTxt = data.significant ? "statistically significant difference" : "not a statistically significant difference";
  document.getElementById("groupStatLine").textContent =
    `t = ${data.t_statistic}, p = ${data.p_value} — ${sigTxt} (\u03b1 = 0.05)`;
}

// ------------------------------------------------------------- correlation
async function loadCorrelation() {
  const data = await api("/api/eda/correlation");
  const corr = data.correlations;
  destroyChart("corr");
  const ctx = document.getElementById("corrChart");
  const maxAbs = Math.max(0.3, ...corr.map(c => Math.abs(c.correlation)));
  charts.corr = new Chart(ctx, {
    type: "bar",
    data: {
      labels: corr.map(c => label(c.feature)),
      datasets: [{
        label: "Correlation with outcome",
        data: corr.map(c => c.correlation),
        backgroundColor: corr.map(c => c.significant ? COLORS.blue : COLORS.gray),
        borderRadius: 4,
      }],
    },
    options: {
      indexAxis: "y",
      plugins: { legend: { display: false } },
      scales: { x: { min: -maxAbs * 1.1, max: maxAbs * 1.1 } },
    },
  });
}

// ------------------------------------------------------------- risk score
function drawGauge(percentile) {
  const cx = 100, cy = 100, r = 80, sw = 16;
  const t = Math.max(0, Math.min(100, percentile)) / 100;
  const startX = cx - r, startY = cy;
  const endX = cx - r * Math.cos(t * Math.PI);
  const endY = cy - r * Math.sin(t * Math.PI);
  const color = percentile < 33 ? COLORS.green : percentile < 66 ? COLORS.orange : "#C0392B";

  const svg = `
    <svg viewBox="0 0 200 115" xmlns="http://www.w3.org/2000/svg">
      <path d="M ${startX} ${startY} A ${r} ${r} 0 0 1 ${cx + r} ${cy}"
            fill="none" stroke="#EEF1F5" stroke-width="${sw}" stroke-linecap="round" />
      <path d="M ${startX} ${startY} A ${r} ${r} 0 0 1 ${endX} ${endY}"
            fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="round" />
    </svg>`;
  document.getElementById("riskGaugeSvg").innerHTML = svg;
  document.getElementById("riskPercentileText").textContent = `${percentile}th`;
  document.getElementById("riskCategoryText").textContent = "";
}

async function buildRiskForm() {
  const ref = await api("/api/risk-score/reference");
  const container = document.getElementById("riskFormFields");

  if (!ref.fields.length) {
    container.innerHTML = `<p class="stat-line">No statistically significant factors were found to build a risk score from.</p>`;
    return;
  }

  container.innerHTML = ref.fields.map(f => {
    if (f.kind === "numeric") {
      return `<div class="field"><label>${label(f.feature)}</label>
        <input type="number" step="any" name="${f.feature}" value="${f.default}" /></div>`;
    }
    const [lbl0, lbl1] = binaryLabels(f.feature, f.label_0, f.label_1);
    return `<div class="field"><label>${label(f.feature)}</label>
      <select name="${f.feature}">
        <option value="0">${lbl0}</option>
        <option value="1">${lbl1}</option>
      </select></div>`;
  }).join("");

  // clear any previous result since the field set may have changed
  document.getElementById("riskPercentileText").textContent = "—";
  document.getElementById("riskCategoryText").textContent = "";
  document.getElementById("riskGaugeSvg").innerHTML = "";
  document.querySelector("#breakdownTable tbody").innerHTML = "";
  document.getElementById("riskExplain").textContent = "";
}

async function submitRiskForm(e) {
  e.preventDefault();
  const form = e.target;
  const payload = {};
  new FormData(form).forEach((v, k) => { payload[k] = Number(v); });

  const data = await api("/api/risk-score", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  drawGauge(data.risk_percentile);
  document.getElementById("riskCategoryText").textContent = data.category;
  document.getElementById("riskExplain").textContent = data.explanation;

  const tbody = document.querySelector("#breakdownTable tbody");
  tbody.innerHTML = data.breakdown.map(b => `
    <tr>
      <td>${label(b.feature)}</td>
      <td>${b.value}</td>
      <td>${b.population_mean}</td>
      <td style="color:${b.contribution >= 0 ? '#C0392B' : '#2E8E86'}">${b.contribution >= 0 ? "+" : ""}${b.contribution}</td>
    </tr>`).join("");
}

// -------------------------------------------------------- target selection
function showTargetModal(columns) {
  const modal = document.getElementById("targetModal");
  const select = document.getElementById("targetModalSelect");
  select.innerHTML = columns.map(c => `<option value="${c}">${c}</option>`).join("");
  document.getElementById("targetModalError").textContent = "";
  modal.style.display = "flex";
}

function hideTargetModal() {
  document.getElementById("targetModal").style.display = "none";
}

document.getElementById("targetModalConfirm").addEventListener("click", async () => {
  const col = document.getElementById("targetModalSelect").value;
  try {
    await api("/api/set-target", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target: col }),
    });
    hideTargetModal();
    await refreshAll();
  } catch (err) {
    document.getElementById("targetModalError").textContent = err.message;
  }
});

// -------------------------------------------------------------- data ctrl
async function refreshAll() {
  await loadOverview();
  await loadCleanReport();
  const hasNumeric = await loadEdaSummary();
  if (hasNumeric) {
    await loadHistogram(document.getElementById("histFeature").value);
    await loadGroupComparison(document.getElementById("groupFeature").value);
  } else {
    destroyChart("hist"); destroyChart("group");
    document.getElementById("groupStatLine").textContent = "";
  }
  await loadCorrelation();
  await buildRiskForm();
}

document.getElementById("histFeature").addEventListener("change", (e) => loadHistogram(e.target.value));
document.getElementById("groupFeature").addEventListener("change", (e) => loadGroupComparison(e.target.value));
document.getElementById("riskForm").addEventListener("submit", submitRiskForm);

document.getElementById("resetBtn").addEventListener("click", async () => {
  await api("/api/reset", { method: "POST" });
  await refreshAll();
});

document.getElementById("csvUpload").addEventListener("change", async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append("file", file);
  try {
    const result = await api("/api/upload", { method: "POST", body: fd });
    if (result.needs_target_selection) {
      showTargetModal(result.columns);
    } else {
      await refreshAll();
    }
  } catch (err) {
    alert("Upload failed: " + err.message);
  }
  e.target.value = "";
});

refreshAll();
