"""
Generates a Framingham Heart Study-schema dataset (framingham.csv).

NOTE: This sandbox has no internet access to kaggle.com, so a synthetic
dataset with the exact same columns, realistic ranges, and realistic
missingness pattern as the real Kaggle "Framingham Heart Study" dataset
is generated here so the pipeline can be built and demoed end-to-end.

To use the REAL data: download from
https://www.kaggle.com/datasets/aasheesh200/framingham-heart-study-dataset
and drop it in as backend/data/framingham.csv (same filename, same columns).
No code changes required elsewhere -- the backend only depends on the schema.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 4238  # same row count as the real Kaggle dataset

# ---- base demographic / lifestyle variables -------------------------------
male = rng.binomial(1, 0.43, N)
age = rng.normal(49.6, 8.6, N).clip(32, 70).round().astype(int)

education = rng.choice([1, 2, 3, 4], size=N, p=[0.42, 0.28, 0.18, 0.12]).astype(float)

currentSmoker = rng.binomial(1, 0.49, N)
cigsPerDay = np.where(
    currentSmoker == 1,
    rng.gamma(2.2, 8.5, N).clip(1, 70).round(),
    0
).astype(float)

BPMeds = rng.binomial(1, np.clip(0.02 + 0.01 * (age > 55), 0, 1), N).astype(float)
prevalentStroke = rng.binomial(1, 0.006, N)
prevalentHyp = rng.binomial(1, np.clip(0.15 + 0.012 * (age - 45).clip(0, None) / 10, 0, 0.85), N)
diabetes = rng.binomial(1, 0.026, N)

# ---- clinical measurements, correlated with age/lifestyle -----------------
totChol = (195 + 0.6 * (age - 49) + rng.normal(0, 35, N) + 8 * currentSmoker).clip(107, 600)
sysBP = (120 + 0.9 * (age - 49) + 18 * prevalentHyp + rng.normal(0, 16, N)).clip(83, 295)
diaBP = (sysBP * 0.62 + rng.normal(0, 7, N)).clip(48, 150)
BMI = (25.5 + 0.03 * (age - 49) + rng.normal(0, 4.0, N)).clip(15, 57)
heartRate = (75 - 0.05 * (age - 49) + 4 * currentSmoker + rng.normal(0, 12, N)).clip(44, 143)
glucose = (79 + 25 * diabetes + 0.15 * (age - 49) + rng.normal(0, 16, N)).clip(40, 395)

# ---- 10-year CHD outcome, built from a latent risk score ------------------
z = (
    0.05 * (age - 49)
    + 0.55 * male
    + 0.45 * currentSmoker
    + 0.015 * cigsPerDay
    + 0.02 * (totChol - 195)
    + 0.035 * (sysBP - 120)
    + 0.06 * (BMI - 25.5)
    + 0.9 * prevalentHyp
    + 1.1 * diabetes
    + 1.3 * prevalentStroke
    + 0.01 * (glucose - 79)
    - 3.35
)
p_chd = 1 / (1 + np.exp(-z))
TenYearCHD = rng.binomial(1, p_chd.clip(0.01, 0.9))

df = pd.DataFrame({
    "male": male,
    "age": age,
    "education": education,
    "currentSmoker": currentSmoker,
    "cigsPerDay": cigsPerDay,
    "BPMeds": BPMeds,
    "prevalentStroke": prevalentStroke,
    "prevalentHyp": prevalentHyp,
    "diabetes": diabetes,
    "totChol": totChol.round(1),
    "sysBP": sysBP.round(1),
    "diaBP": diaBP.round(1),
    "BMI": BMI.round(2),
    "heartRate": heartRate.round().astype(float),
    "glucose": glucose.round().astype(float),
    "TenYearCHD": TenYearCHD,
})

# ---- inject realistic missingness (MCAR-ish, matching real dataset rates) -
missing_rates = {
    "education": 0.025,
    "cigsPerDay": 0.007,
    "BPMeds": 0.0125,
    "totChol": 0.012,
    "BMI": 0.004,
    "heartRate": 0.0002,
    "glucose": 0.093,
}
for col, rate in missing_rates.items():
    mask = rng.random(N) < rate
    df.loc[mask, col] = np.nan

out_path = __file__.replace("generate_dataset.py", "framingham.csv")
df.to_csv(out_path, index=False)
print(f"Wrote {len(df)} rows to {out_path}")
print(df.isna().sum())
print("\nTenYearCHD distribution:\n", df["TenYearCHD"].value_counts())
