"""
FastAPI backend for: Exploratory Statistical Analysis of Clinical and
Lifestyle Indicators for Early Health Risk.

Pipeline: load -> clean -> EDA (distributions) -> statistical correlation
-> percentile-based statistical risk scoring.

No ML/DL model is trained anywhere in this pipeline. Risk scoring is a
transparent, explainable statistical calculation: correlation-weighted
z-scores, ranked against the historical study population.

GENERALIZED SCHEMA HANDLING: ships with the Framingham Heart Study dataset
by default, but the pipeline is schema-agnostic -- any CSV with a binary
(two-value) outcome column works. Text/categorical columns are
automatically label-encoded. The outcome column is auto-detected by name
(target/outcome/diagnosis/...) or, failing that, by finding the dataset's
only binary column. If detection is ambiguous, /api/upload responds with
needs_target_selection so the frontend can show a column picker, and the
choice is committed via /api/set-target.
"""
import io
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from scipy import stats

from fastapi import FastAPI, UploadFile, File, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

BASE_DIR = Path(__file__).parent
DATA_PATH = BASE_DIR / "data" / "framingham.csv"
FRONTEND_DIR = BASE_DIR.parent / "frontend"
DEFAULT_TARGET = "TenYearCHD"

TARGET_NAME_HINTS = [
    "tenyearchd", "target", "outcome", "diagnosis", "label", "class",
    "disease", "stroke", "chd", "result", "risk", "num",
]

app = FastAPI(title="Early Health Risk - Statistical Analysis API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def no_cache_headers(request, call_next):
    """Prevent the browser from ever caching stale HTML/CSS/JS across restarts
    -- important for a local dev tool served from a fixed 127.0.0.1 URL."""
    response = await call_next(request)
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
    response.headers["Pragma"] = "no-cache"
    return response


# ---------------------------------------------------------------------------
# In-memory state
# ---------------------------------------------------------------------------
state = {
    "raw": None,             # dataframe actually in use (after dropping id-like cols)
    "clean": None,            # encoded + imputed
    "target": None,
    "numeric_features": None,
    "binary_features": None,
    "feature_types": None,    # {feature: "numeric" | "binary"}
    "encoders": None,         # {column: [original category values in code order]}
    "excluded_columns": None,  # [{"column": ..., "reason": ...}]
    "stats": None,
    "raw_scores": None,
    "pending_raw": None,      # holds an uploaded df awaiting target selection
}


def load_default_dataset() -> pd.DataFrame:
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            f"No dataset found at {DATA_PATH}. Place a CSV there or upload one."
        )
    return pd.read_csv(DATA_PATH)


def detect_target(df: pd.DataFrame) -> Optional[str]:
    """Exact column-name hint match first, then substring match, then fall
    back to 'the only binary column' or 'the last column if it's binary'."""
    cols_lower = {c.lower(): c for c in df.columns}

    for hint in TARGET_NAME_HINTS:
        if hint in cols_lower and df[cols_lower[hint]].dropna().nunique() == 2:
            return cols_lower[hint]

    for hint in TARGET_NAME_HINTS:
        for lower, original in cols_lower.items():
            if hint in lower and df[original].dropna().nunique() == 2:
                return original

    binary_cols = [c for c in df.columns if df[c].dropna().nunique() == 2]
    if len(binary_cols) == 1:
        return binary_cols[0]
    last = df.columns[-1]
    if df[last].dropna().nunique() == 2:
        return last
    return None


def drop_identifier_columns(df: pd.DataFrame, target: str) -> tuple[pd.DataFrame, list]:
    """Drop obvious ID/row-index columns (e.g. 'id', 'patient_id') so they
    don't pollute correlation/risk-score results as meaningless noise."""
    excluded = []
    id_like = []
    for col in df.columns:
        if col == target:
            continue
        name = col.lower().strip()
        looks_like_id = name in ("id", "index", "unnamed: 0") or name.endswith("_id") or name.endswith("id")
        fully_unique = df[col].nunique(dropna=True) == len(df)
        if looks_like_id and fully_unique:
            id_like.append(col)
            excluded.append({"column": col, "reason": "identifier column (unique per row)"})
    df = df.drop(columns=id_like) if id_like else df
    return df, excluded


def encode_dataframe(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Label-encode any non-numeric columns to integers so every column is
    usable in correlation/z-score math. Returns (encoded_df, encoders)
    where encoders maps column -> [original category values in code order]."""
    df = df.copy()
    encoders = {}
    for col in df.columns:
        if not pd.api.types.is_numeric_dtype(df[col]):
            codes, uniques = pd.factorize(df[col], sort=True)
            codes = codes.astype(float)
            codes[codes == -1] = np.nan
            df[col] = codes
            encoders[col] = list(uniques)
    return df, encoders


def classify_features(df: pd.DataFrame, target: str) -> dict:
    types = {}
    for c in df.columns:
        if c == target:
            continue
        nunique = df[c].dropna().nunique()
        types[c] = "binary" if nunique <= 10 else "numeric"
    return types


def clean_dataset(df: pd.DataFrame, target: str, feature_types: dict) -> pd.DataFrame:
    df = df.copy()
    for col, kind in feature_types.items():
        if col not in df.columns or not df[col].isna().any():
            continue
        if kind == "numeric":
            df[col] = df[col].fillna(df[col].median())
        else:
            mode = df[col].mode()
            df[col] = df[col].fillna(mode.iloc[0] if len(mode) else 0)
    if df[target].isna().any():
        mode = df[target].mode()
        df[target] = df[target].fillna(mode.iloc[0] if len(mode) else 0)
    return df


def compute_statistics(df: pd.DataFrame, target: str, all_features: list) -> dict:
    results = []
    for col in all_features:
        try:
            r, p = stats.pearsonr(df[col].astype(float), df[target].astype(float))
        except Exception:
            continue
        if np.isnan(r):
            continue
        results.append({
            "feature": col,
            "correlation": round(float(r), 4),
            "p_value": round(float(p), 5),
            "significant": bool(p < 0.05),
        })
    results.sort(key=lambda x: abs(x["correlation"]), reverse=True)

    feature_means = {c: float(df[c].mean()) for c in all_features}
    feature_stds = {c: (float(df[c].std()) or 1.0) for c in all_features}

    sig = [r["feature"] for r in results if r["significant"]]
    if not sig and results:
        sig = [r["feature"] for r in results[:min(5, len(results))]]

    return {
        "correlations": results,
        "means": feature_means,
        "stds": feature_stds,
        "significant_features": sig,
    }


def compute_raw_scores(df: pd.DataFrame, stats_dict: dict) -> np.ndarray:
    sig = stats_dict["significant_features"]
    weights = {r["feature"]: r["correlation"] for r in stats_dict["correlations"]}
    means = stats_dict["means"]
    stds = stats_dict["stds"]

    raw = np.zeros(len(df))
    for f in sig:
        z = (df[f].astype(float).values - means[f]) / (stds[f] if stds[f] else 1.0)
        raw += z * weights[f]
    return raw


def build_pipeline(df_raw: pd.DataFrame, target: str):
    """Run the full pipeline for a df + confirmed target and commit it to
    global state. Raises ValueError(str) on a genuine data problem."""
    if target not in df_raw.columns:
        raise ValueError(f"Column '{target}' not found in the uploaded file.")
    if df_raw[target].dropna().nunique() != 2:
        raise ValueError(
            f"Column '{target}' is not binary (needs exactly 2 distinct values), "
            "so it can't be used as a risk outcome."
        )

    df_raw, excluded = drop_identifier_columns(df_raw, target)
    df_encoded, encoders = encode_dataframe(df_raw)
    feature_types = classify_features(df_encoded, target)
    all_features = [c for c in df_encoded.columns if c != target]
    df_clean = clean_dataset(df_encoded, target, feature_types)
    stats_dict = compute_statistics(df_clean, target, all_features)
    raw_scores = compute_raw_scores(df_clean, stats_dict)

    state.update({
        "raw": df_raw,
        "clean": df_clean,
        "target": target,
        "numeric_features": [f for f in all_features if feature_types.get(f) == "numeric"],
        "binary_features": [f for f in all_features if feature_types.get(f) == "binary"],
        "feature_types": feature_types,
        "encoders": encoders,
        "excluded_columns": excluded,
        "stats": stats_dict,
        "raw_scores": raw_scores,
        "pending_raw": None,
    })


build_pipeline(load_default_dataset(), target=DEFAULT_TARGET)


def binary_labels_for(col: str) -> dict:
    """Return {'0': label, '1': label} for a binary column, using the
    original text categories if this column was label-encoded, else plain
    '0'/'1' (the frontend fills in friendlier wording for known columns)."""
    enc = state["encoders"].get(col)
    if enc and len(enc) == 2:
        return {"0": str(enc[0]), "1": str(enc[1])}
    return {"0": "0", "1": "1"}


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/upload")
async def upload_dataset(file: UploadFile = File(...)):
    if not file.filename.endswith(".csv"):
        raise HTTPException(400, "Please upload a .csv file")
    content = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(content))
    except Exception as e:
        raise HTTPException(400, f"Could not parse CSV: {e}")
    if len(df.columns) < 2:
        raise HTTPException(400, "CSV needs at least 2 columns (features + an outcome column)")

    target = detect_target(df)
    if target is None:
        state["pending_raw"] = df
        return {"needs_target_selection": True, "columns": list(df.columns)}

    try:
        build_pipeline(df, target)
    except ValueError as e:
        raise HTTPException(422, str(e))

    return {
        "message": f"Loaded {len(df)} rows",
        "rows": len(df),
        "target": state["target"],
    }


@app.post("/api/set-target")
def set_target(payload: dict = Body(...)):
    target = payload.get("target")
    if state["pending_raw"] is None:
        raise HTTPException(400, "No uploaded file is waiting for a target column.")
    if not target:
        raise HTTPException(400, "No target column given.")
    try:
        build_pipeline(state["pending_raw"], target)
    except ValueError as e:
        raise HTTPException(422, str(e))
    return {"message": "ok", "target": state["target"]}


@app.post("/api/reset")
def reset_dataset():
    build_pipeline(load_default_dataset(), target=DEFAULT_TARGET)
    return {"message": "Reset to bundled dataset", "target": state["target"]}


@app.get("/api/overview")
def overview():
    raw = state["raw"]
    clean = state["clean"]
    target = state["target"]
    missing = raw.isna().sum()
    missing = {c: int(v) for c, v in missing.items() if v > 0}
    target_dist = clean[target].value_counts().to_dict()
    return {
        "rows": int(len(raw)),
        "columns": int(raw.shape[1]),
        "target": target,
        "target_labels": binary_labels_for(target),
        "numeric_features": state["numeric_features"],
        "binary_features": state["binary_features"],
        "missing_before_cleaning": missing,
        "total_missing_cells": int(raw.isna().sum().sum()),
        "target_distribution": {str(k): int(v) for k, v in target_dist.items()},
        "excluded_columns": state["excluded_columns"],
        "column_list": list(raw.columns),
    }


@app.get("/api/clean-report")
def clean_report():
    raw = state["raw"]
    feature_types = state["feature_types"]
    before = raw.isna().sum()
    report = []
    for col in list(state["numeric_features"]) + list(state["binary_features"]):
        n_missing = int(before.get(col, 0))
        if n_missing == 0:
            continue
        kind = feature_types.get(col, "numeric")
        method = "median imputation" if kind == "numeric" else "mode imputation"
        report.append({
            "feature": col,
            "missing_count": n_missing,
            "missing_pct": round(100 * n_missing / len(raw), 2),
            "method": method,
        })
    report.sort(key=lambda x: x["missing_count"], reverse=True)
    return {"total_rows": len(raw), "report": report}


@app.get("/api/eda/summary")
def eda_summary():
    clean = state["clean"]
    out = []
    for col in list(state["numeric_features"]) + list(state["binary_features"]):
        s = clean[col].astype(float)
        out.append({
            "feature": col,
            "mean": round(float(s.mean()), 2),
            "median": round(float(s.median()), 2),
            "std": round(float(s.std()), 2),
            "min": round(float(s.min()), 2),
            "max": round(float(s.max()), 2),
        })
    return {"summary": out}


@app.get("/api/eda/histogram")
def eda_histogram(column: str, bins: int = 12):
    clean = state["clean"]
    if column not in clean.columns:
        raise HTTPException(404, f"Unknown column: {column}")
    values = clean[column].astype(float).values
    counts, edges = np.histogram(values, bins=bins)
    labels = [f"{edges[i]:.1f}-{edges[i+1]:.1f}" for i in range(len(edges) - 1)]
    return {"column": column, "labels": labels, "counts": counts.tolist()}


@app.get("/api/eda/correlation")
def eda_correlation():
    return {"correlations": state["stats"]["correlations"], "target": state["target"]}


@app.get("/api/eda/grouped-comparison")
def grouped_comparison(column: str):
    """Compare mean of a column between the two outcome groups, with an
    independent t-test p-value -- classic statistical EDA, not ML."""
    clean = state["clean"]
    target = state["target"]
    if column not in clean.columns or column == target:
        raise HTTPException(404, f"Unknown column: {column}")
    levels = sorted(clean[target].dropna().unique().tolist())
    if len(levels) != 2:
        raise HTTPException(400, "Target is not binary")
    g0 = clean.loc[clean[target] == levels[0], column].astype(float)
    g1 = clean.loc[clean[target] == levels[1], column].astype(float)
    t, p = stats.ttest_ind(g0, g1, equal_var=False)
    lbl = binary_labels_for(target)
    return {
        "column": column,
        "target": target,
        "group_0_label": lbl["0"],
        "group_1_label": lbl["1"],
        "mean_group_0": round(float(g0.mean()), 2),
        "mean_group_1": round(float(g1.mean()), 2),
        "t_statistic": round(float(t), 3),
        "p_value": round(float(p), 5),
        "significant": bool(p < 0.05),
    }


@app.get("/api/risk-score/reference")
def risk_score_reference():
    stats_dict = state["stats"]
    sig = stats_dict["significant_features"]
    fields = []
    for f in sig:
        kind = state["feature_types"].get(f, "numeric")
        if kind == "numeric":
            fields.append({
                "feature": f,
                "kind": "numeric",
                "default": round(stats_dict["means"][f], 2),
            })
        else:
            lbl = binary_labels_for(f)
            fields.append({
                "feature": f,
                "kind": "binary",
                "default": 0,
                "label_0": lbl["0"],
                "label_1": lbl["1"],
            })
    return {
        "target": state["target"],
        "fields": fields,
        "population_size": len(state["raw_scores"]),
        "score_min": round(float(state["raw_scores"].min()), 3),
        "score_max": round(float(state["raw_scores"].max()), 3),
    }


@app.post("/api/risk-score")
def risk_score(payload: dict = Body(...)):
    """Compute a statistical risk percentile for one individual's values.
    Any significant feature not provided falls back to the population mean."""
    stats_dict = state["stats"]
    means = stats_dict["means"]
    stds = stats_dict["stds"]
    sig = stats_dict["significant_features"]
    weights = {r["feature"]: r["correlation"] for r in stats_dict["correlations"]}
    raw_scores = state["raw_scores"]

    if not sig:
        raise HTTPException(400, "No usable factors to compute a risk score from.")

    breakdown = []
    raw = 0.0
    for f in sig:
        val = payload.get(f, means[f])
        try:
            val = float(val)
        except (TypeError, ValueError):
            val = means[f]
        z = (val - means[f]) / (stds[f] if stds[f] else 1.0)
        contribution = z * weights[f]
        raw += contribution
        breakdown.append({
            "feature": f,
            "value": round(val, 3),
            "population_mean": round(means[f], 2),
            "z_score": round(z, 3),
            "correlation_weight": round(weights[f], 3),
            "contribution": round(contribution, 3),
        })

    percentile = float(stats.percentileofscore(raw_scores, raw, kind="mean"))
    if percentile < 33:
        category = "Lower Relative Risk"
    elif percentile < 66:
        category = "Moderate Relative Risk"
    else:
        category = "Higher Relative Risk"

    breakdown.sort(key=lambda x: abs(x["contribution"]), reverse=True)
    return {
        "raw_score": round(raw, 3),
        "risk_percentile": round(percentile, 1),
        "category": category,
        "breakdown": breakdown,
        "explanation": (
            "Percentile shows where this individual's correlation-weighted "
            "statistical score falls relative to the study population -- "
            "not a trained prediction, just a ranked statistical comparison."
        ),
    }


# ---------------------------------------------------------------------------
# Serve the static frontend
# ---------------------------------------------------------------------------
app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
